
module.exports = (name, geolocation) => ({
  name: name,
  geolocation: geolocation,
  type: 'destinationProposed'
})
