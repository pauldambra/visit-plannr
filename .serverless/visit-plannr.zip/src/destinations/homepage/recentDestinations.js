
module.exports = {
  topFive: dynamoDocumentClient => {
    return []
  }
}
