#! /bin/bash

set -eux

make -j 2 run_local
