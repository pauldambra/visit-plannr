#! /bin/bash

set -eux

rm -rf node_modules/

npm ci --only=production


