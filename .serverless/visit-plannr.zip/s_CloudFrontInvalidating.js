var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'pauldambra',
applicationName: 'visit-plannr',
appUid: '9Wwp3mDWlJHCGRtWwk',
orgUid: 'SXBNJP59BmjtB5p3gb',
deploymentUid: 'ec3d1ee1-94e0-4b5c-a085-50ec564eb3b0',
serviceName: 'visit-plannr',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'visit-plannr-dev-CloudFrontInvalidating', timeout: 10}
try {
  const userHandler = require('./src/invalidateStaticFiles.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
